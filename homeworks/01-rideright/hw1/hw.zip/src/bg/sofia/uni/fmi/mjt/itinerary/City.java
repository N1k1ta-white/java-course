package bg.sofia.uni.fmi.mjt.itinerary;

public record City(String name, Location location) {
}
