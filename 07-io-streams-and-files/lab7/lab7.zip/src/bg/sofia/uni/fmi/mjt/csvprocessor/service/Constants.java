package bg.sofia.uni.fmi.mjt.csvprocessor.service;

public class Constants {
    private static final int MIN_LENGTH = 3;

    public static int getMinLength() {
        return MIN_LENGTH;
    }
}
